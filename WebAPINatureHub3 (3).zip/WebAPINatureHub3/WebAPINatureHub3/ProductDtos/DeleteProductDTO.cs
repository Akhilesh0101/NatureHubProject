﻿namespace WebAPINatureHub3.ProductDtos
{
    public class DeleteProductDTO
    {
        public int ProductId { get; set; }
    }
}
