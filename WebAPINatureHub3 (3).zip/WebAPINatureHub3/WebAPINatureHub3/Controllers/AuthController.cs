﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BCrypt.Net;
using Microsoft.Extensions.Configuration;
using System.Linq;
using WebAPINatureHub3.Models;
using Microsoft.CodeAnalysis.Scripting;
using System.Configuration;
using System.ComponentModel.DataAnnotations;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly NatureHub3Context _context;
        private readonly IConfiguration _configuration;

        public AuthController(NatureHub3Context context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // Admin Login
        [HttpPost("adminlogin")]
        public IActionResult AdminLogin([FromBody] AdminLoginDto loginDto)
        {
            var admin = _context.Admins.SingleOrDefault(u => u.Username == loginDto.Username && u.Email == loginDto.Email && u.Password == loginDto.Password);
            if (admin == null) { return Unauthorized("Admin not found."); }
            // Validate the password
            if (admin.Password != loginDto.Password)
            {
                return Unauthorized("Invalid password.");
            }
            var token = GenerateJwtToken(admin.Username, "Admin");
            return Ok(new { token });
        }

        // User Login
        [HttpPost("userlogin")]
        public IActionResult UserLogin([FromBody] UserLoginDto loginDto)
        {
            var user = _context.Users.SingleOrDefault(u => u.UserName == loginDto.UserName && u.Email == loginDto.Email && u.Password == loginDto.Password);
            if (user == null) { return Unauthorized("User not found."); }
            // Validate the password
            if (user.Password != loginDto.Password)
            {
                return Unauthorized("Invalid password.");
            }
            var token = GenerateJwtToken(user.UserName, "User");
            return Ok(new { token });
        }

        // User Signup
        [HttpPost("signup")]
        public async Task<IActionResult> Signup([FromForm] UserSignupDto signupDto)
        {
            // Check if the username or email already exists
            if (_context.Users.Any(u => u.UserName == signupDto.UserName || u.Email == signupDto.Email))
            {
                return BadRequest("Username or Email already exists.");
            }

            // Create a new user
            var user = new User
            {
                UserName = signupDto.UserName,
                Email = signupDto.Email,
                Password = signupDto.Password, // Ensure password hashing
                RoleId = 2 // Default RoleId for users
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUser", "Users", new { id = user.UserId }, user);
        }

        private string GenerateJwtToken(string username, string role)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, username),
                new Claim(ClaimTypes.Role, role),
            };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credential = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(50),
                signingCredentials: credential
            );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }

    // DTOs
    public class AdminLoginDto
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class UserLoginDto
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class UserSignupDto
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}