﻿namespace WebAPINatureHub3.HealthTipsDtos
{
    public class DeleteHealthTipDTO
    {
        public int TipId { get; set; }
    }
}
