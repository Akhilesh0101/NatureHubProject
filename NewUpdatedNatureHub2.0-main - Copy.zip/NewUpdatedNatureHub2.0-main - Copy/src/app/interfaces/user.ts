export interface User {
    userId:number,
    username: string;
  userImage: string;
  email: string;  // For sign-up, email is also needed
  password:string;
}
