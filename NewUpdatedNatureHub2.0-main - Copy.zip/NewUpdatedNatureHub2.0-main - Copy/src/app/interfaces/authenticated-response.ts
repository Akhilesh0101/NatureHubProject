export interface AuthenticatedResponse {
    token: string;

}
